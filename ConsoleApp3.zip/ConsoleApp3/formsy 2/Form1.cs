namespace formsy_2
{
    public partial class Form1 : Form
    {
        char[] cyfry = {'!', '@' , '#' , '$', '%', '^','&','*','(',')' };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string haslo = "";
            Random random = new Random();
            int.TryParse(textBox3.Text, out int liczba);
            int i = 0;
            if (checkBox1.Checked)
            {
                int index = random.Next(cyfry.Length - 1);
                haslo += cyfry[index];
                ++i;
            }
            for (; i <liczba; i++)
            {
                haslo+=random.Next(10);
            }
           
            MessageBox.Show(haslo);
        }

    }
}