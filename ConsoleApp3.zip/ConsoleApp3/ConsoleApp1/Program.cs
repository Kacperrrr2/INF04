﻿namespace Wartownik
{
    internal class Program
    {
        void Wypełnij(int[]tab,int x)
        {

            for (int i = 0; i < tab.Length-1; i++) 
            {
                Random random = new Random();
                tab[i]=random.Next(1,101);
            }
            tab[tab.Length - 1] = x;
        }
        void Szukaj(int[]tab,int szukana)
        {
            int i = 0;
            while (tab[i]!=szukana) 
            {
                i++;
            
            }

            if (i==tab.Length-1)
            {
                Console.WriteLine("nie znaleziono szukany elemnt");
            }
            else
            {
                Console.WriteLine("znaleziono szukany elemnt");
            }
        }
        static void Main(string[] args)
        {
            Program program = new Program();
            int[] tab = new int[51];
            int szukana=Int32.Parse(Console.ReadLine());
            program.Wypełnij(tab,szukana);
            program.Szukaj(tab,szukana);
        }
    }
}