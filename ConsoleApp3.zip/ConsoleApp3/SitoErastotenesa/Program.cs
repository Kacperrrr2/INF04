﻿namespace SitoErastotenesa
{
    internal class Program
    {
        bool[] tab = new bool[101];

        void Wypelnij()
        {
           for (int i = 2; i < tab.Length; i++) 
           {
                tab[i] = true;
           }

        }
        void SitoErastotenesa()
        {
            for(int i = 2;i<Math.Sqrt(tab.Length);i++)
            {
                if ((tab[i])==true)
                {
                    for (int j = 2*i; j <tab.Length; j+=i)
                    {
                        tab[j] = false;
                    }
                }
            }
        }
        void Wyszukaj()
        {
            for (int i = 0; i < tab.Length; i++)
            {
                if (tab[i]==true)
                {
                    Console.WriteLine(i);
                }
            }
        }
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Wypelnij();
            program.SitoErastotenesa();
            program.Wyszukaj();
        }
    }
}