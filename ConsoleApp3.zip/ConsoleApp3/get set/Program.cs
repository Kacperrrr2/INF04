﻿

namespace get_set
{
    internal class Film
    {
        string film;
        int liczbawypozeczen;
        public Film()
        { 
            film = "";
            liczbawypozeczen= 0;
        }
        void setTytul(string film)
        { 
            this.film = film;
        }
        string getTytul()
        {
            return film;
        }
        int getLiczbaWYbozyczen()
        {
            return liczbawypozeczen;
        }
        void InkrementacjaLiczbyWypoztczen()
        {
            liczbawypozeczen += 1;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}