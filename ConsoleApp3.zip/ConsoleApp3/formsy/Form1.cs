using System.Windows.Forms;

namespace formsy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label4.Text = "1.5 Z�";
            }
            else if (radioButton2.Checked)
            {
                label4.Text = "2.5 Z�";
            }
            else if (radioButton3.Checked)
            {
                label4.Text = "3.5Z�";
            }
        }

  

        private void button2_Click(object sender, EventArgs e)
        {
            string sprawdz= textBox2.Text;
            if (sprawdz.Length == 5)
            {

                    if(int.TryParse(sprawdz,out int test )==true)
                    {
                        MessageBox.Show("Sprawdzone liczby s� poprawne"+ test);
                        
                    }
                    else
                    {
                        MessageBox.Show("Nie jest liczb�");
                    }
                
            }
            else
            {
                MessageBox.Show("Nieprawid�owa liczba cyfr w kodzie pocztowym");
            }
        }
    }
}