﻿namespace SortowanieprzezMin
{
    internal class Program
    {
        int[]tab=new int[10];
        void Wpisz()
        {
            for(int i = 0; i < tab.Length; i++)
            {
                tab[i]=Int32.Parse(Console.ReadLine());
            }
        }
        void Wypisz()
        {
            for (int i = 0;i < tab.Length;i++)
            {
                Console.WriteLine(tab[i]+ "\n");
            }
        }
        void Sortowanie()
        {
            for (int i = 0; i < tab.Length; i++)
            {
                int najmniejszy = ZnajdzNajmnieszyIndex(i);
                Swap(i, najmniejszy);
            }
        }
        int ZnajdzNajmnieszyIndex(int minIndex)
        {
            for (int i = minIndex+1; i < tab.Length;i++)
            {
                if (tab[minIndex] > tab[i])
                {
                    minIndex= i;
                }
            }
            return minIndex;
        }
        void Swap(int index1, int index2)
        {
            int t = tab[index1];
            tab[index1] = tab[index2];
            tab[index2] = t;
        }


        static void Main(string[] args)
        {
            Program program= new Program();
            program.Wpisz();
            program.Sortowanie();
            program.Wypisz();
            Console.ReadLine();
        }
    }
}