﻿using System.Data;

namespace BubbleSort
{
    internal class Program
    {
        int[] tab = { 2, 56, 6, 3, 2, 1 };
        void BubbleSort()
        {
            for (int i = 0; i < tab.Length; i++) 
            {
                for(int j = 0;j<tab.Length-1;j++)
                {
                    if(tab[j + 1] > tab[j])
                    {
                        Swap(j+1, j);
                    }
                }
            
            }

        }
        void Swap(int index1,int index2)
        {
            int t = tab[index1];
            tab[index1] = tab[index2];
            tab[index2]=t;
        }
        void Wypisz()
        {
            for (int i = 0; i < tab.Length; i++)
            {
                Console.WriteLine(tab[i] +"\n");
            }
        }
        static void Main(string[] args)
        {
            Program p=new Program();
            p.BubbleSort();
            p.Wypisz();

        }
    }
}