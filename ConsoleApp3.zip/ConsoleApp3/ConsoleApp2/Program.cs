﻿namespace SortowaniePrzezWstawienie
{
    internal class Program
    {
        int[] tab = { 55, 88, 5, 7, 9 };
        void SortowaniePrzezWstawienie()
        {
            for (int i = 1; i < tab.Length; i++)
            {
                int key = tab[i];
                int j = i - 1;
                while (j >= 0 && tab[j] > key)
                {
                    tab[j + 1] = tab[j];
                    --j;
                }
                tab[j + 1] = key;


            }
        }
        void Wypisz()
        {
            for(int i = 0;i < tab.Length;i++)
            {
                Console.WriteLine(tab[i] +"\n");
            }
        }
        static void Main(string[] args)
        {
           Program p = new Program();
            p.SortowaniePrzezWstawienie();
            p.Wypisz();
        }
    }
}